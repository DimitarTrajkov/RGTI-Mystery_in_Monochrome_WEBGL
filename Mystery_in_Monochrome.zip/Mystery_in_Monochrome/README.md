# RGTI-Mystery_in_Monochrome_WEBGL

to start the game:
RGTI-Mystery_in_Monochrome_WEBGL> node server.js